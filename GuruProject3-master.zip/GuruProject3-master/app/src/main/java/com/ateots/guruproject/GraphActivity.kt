package com.ateots.guruproject

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.fragment.app.FragmentManager
import androidx.fragment.app.FragmentTransaction


class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_graph)

        supportFragmentManager.beginTransaction()
            .replace(R.id.fragment, GraphFragment())
            .commit()


        /*val linechart: LineChart = findViewById(R.id.Linechart)

        val entries: ArrayList<Entry> = ArrayList()
        val stickylabel: TextView = findViewById(R.id.stickyLabel)

        entries.add(Entry(1f, 0F))
        entries.add(Entry(2f, 2f))
        entries.add(Entry(3f, 4f))
        entries.add(Entry(4f, 6f))
        entries.add(Entry(5f, 3f))

        val dataSet: LineDataSet = LineDataSet(entries, "날짜")
        dataSet.lineWidth = 2f
        dataSet.circleRadius = 4f
        dataSet.setCircleColor(Color.parseColor("#ffffff"))
        dataSet.circleHoleColor = Color.BLUE
        dataSet.setDrawCircleHole(true)
        dataSet.setDrawCircles(true)
        dataSet.setDrawFilled(true)
        dataSet.fillColor = Color.WHITE

        /*
        if (Utils.getSDKInt() >= 18) {
            val drawable = ContextCompat.getDrawable(this, R.drawable.fade_red)
            dataSet.fillDrawable = drawable
        } else {
            dataSet.fillColor = Color.BLACK
        }*/
        //dataSet.mode = LineDataSet.Mode.CUBIC_BEZIER
        dataSet.setDrawHorizontalHighlightIndicator(false)
        dataSet.setDrawHighlightIndicators(false)
        dataSet.setDrawValues(false)

        val lineData: LineData = LineData(dataSet)
        linechart.data = lineData

        val xAxis: XAxis = linechart.xAxis
        xAxis.position = XAxis.XAxisPosition.BOTTOM
        xAxis.textColor = Color.BLACK
        xAxis.textSize = 11f
        xAxis.granularity = 1f
        xAxis.valueFormatter = StickyDateAxisValueFormatter(chart = linechart, sticky = stickylabel)

        xAxis.enableGridDashedLine(8f, 24f, 0f)

        val yLAxis: YAxis = linechart.axisLeft
        yLAxis.textColor = Color.BLACK
        // yLAxis.setAxisMinValue(0.3f)
        yLAxis.valueFormatter = TimeAxisValueFormatter()

        val yRAxis: YAxis = linechart.axisRight
        yRAxis.setDrawLabels(false)
        yRAxis.setDrawAxisLine(false)
        yRAxis.setDrawGridLines(false)

        val description: Description = Description()
        description.text = ""

        linechart.isDoubleTapToZoomEnabled = false
        // 뒷배경에 선 그리기
        linechart.setDrawGridBackground(false)
        linechart.description = description
        linechart.animateY(2000, Easing.EaseInCubic)
        linechart.invalidate()
        linechart.xAxis.yOffset = 15f
        linechart.axisLeft.xOffset = 15f

        val marker: ExampleMarker = ExampleMarker(this, R.layout.activity_markerview)
        marker.chartView = linechart
        linechart.marker = marker

    }*/
    }
}

/*class StickyDateAxisValueFormatter : ValueFormatter {
    private var c: GregorianCalendar
    private var chart: LineChart
    private var sticky: TextView
    private var lastFormattedValue = 1e9f
    private var lastMonth = 0
    private var lastYear = 0
    private var stickyMonth = -1
    private var stickyYear = -1
    private val mFormat =
        SimpleDateFormat("dd MMM", Locale.ENGLISH)

    constructor(chart: LineChart, sticky: TextView) {
        c = GregorianCalendar()
        this.chart = chart
        this.sticky = sticky
    }

    override fun getFormattedValue(value: Float): String? {
        if (value < chart.lowestVisibleX) {
            return ""
        }

        val days: Float = value
        val isFirstValue: Boolean = value < lastFormattedValue

        if (isFirstValue) {
            lastMonth = 50
            lastYear = 5000

            c.set(2020, 8, 10)
            c.add(GregorianCalendar.DATE, chart.lowestVisibleX.toInt())

            stickyMonth = c.get(GregorianCalendar.MONTH)
            stickyYear = c.get(GregorianCalendar.YEAR)

            val stickyText: String = mFormat.format(c.time)
            sticky.setText(stickyText)
        }

        c.set(2020, 8, 10)
        c.add(GregorianCalendar.DATE, days.toInt())
        val d: Date = c.time

        val dayOfMonth: Int = c.get(GregorianCalendar.DAY_OF_MONTH)
        val month: Int = c.get(GregorianCalendar.MONTH)
        val year: Int = c.get(GregorianCalendar.YEAR)

        val monthString: String = mFormat.format(d)

        if ((month > stickyMonth || year > stickyYear) && !isFirstValue) {
            stickyMonth = month
            stickyYear = year
            val stickyText: String = monthString + "\n" + year
            sticky.setText(stickyText)
        }

        val ret: String

        if ((month > lastMonth || year > lastYear) && isFirstValue) {
            ret = monthString
        } else {
            ret = dayOfMonth.toString();
        }

        lastMonth = month
        lastYear = year
        lastFormattedValue = value

        return month.toString() + "월" + ret + "일"
    }
}

class TimeAxisValueFormatter : ValueFormatter()
{
    var currentDateTimeString: String = DateFormat.getDateTimeInstance().format(Date())
    //val sdf = SimpleDateFormat("dd/M/yyyy hh:mm:ss")
    //var Strnow = now.format(DateTimeFormatter.ofPattern("yyyy-MM-dd"))

    // var datenow = LocalDate.parse(Strnow, DateTimeFormatter.ISO_DATE)
    private val tFormat = SimpleDateFormat("H시간", Locale.ENGLISH)


    override fun getFormattedValue(value: Float): String? {
       // val currentDate = sdf.format(Date())
        // return currentDate
        val millis = TimeUnit.HOURS.toMillis(value.toLong())
        val rTime = millis + 1
        return tFormat.format(Date(rTime))
    }
}*/

/*class setData{

    fun settingData(count : Int, range : Float)
    {
        var now =
            TimeUnit.MILLISECONDS.toHours(System.currentTimeMillis())

        var values: ArrayList<Entry> = ArrayList()

        val to = (now + count).toFloat()

        fun getRandom(range : Float, start : Float): Float {
            return ((Math.random() * range) + start).toFloat()
        }

        for (x in now until to.toInt()) {
           val y: Float = getRandom(range, 50.toFloat())
            values.add(Entry(x.toFloat(), y)) // add one entry per hour
        }
    }

}*/



